var searchData=
[
  ['proposition',['Proposition',['../struct_jackyjjc_1_1_bayesianet_1_1_proposition.html',1,'Jackyjjc::Bayesianet']]]
];
