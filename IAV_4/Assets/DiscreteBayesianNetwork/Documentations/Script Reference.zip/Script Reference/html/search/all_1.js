var searchData=
[
  ['distribution',['Distribution',['../class_jackyjjc_1_1_bayesianet_1_1_bayesian_node.html#adb5d6c98a48a3bcb466ec9c0a0914a27',1,'Jackyjjc::Bayesianet::BayesianNode']]]
];
